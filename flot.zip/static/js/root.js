/* ROOT*/
const ROOT_QUESTIONS = document.getElementById('questions_all');
const ROOT_SPINNER = document.getElementById('spinner');
const ROOT_ERROR = document.getElementById('error');
