function ScoreBuild(answer){
	if (answer == true){ 
		score_build++;
		document.getElementById("score_build").innerHTML = score_build;
	}
}
function ScoreFood(answer){
	if (answer == true){ 
		score_food++;
		document.getElementById("score_food").innerHTML = score_food;
	}
}

function ScoreCat(answer){
	if (answer == true){ 
		score_cat++;
		document.getElementById("score_cat").innerHTML = score_cat;
	}
}

function ScoreMap(answer){
	if (answer == true){ 
		score_map++;
		document.getElementById("score_map").innerHTML = score_map;
	}
}

function ScoreWheeel(answer){
	if (answer == true){ 
		score_wheel++;
		document.getElementById("score_wheel").innerHTML = score_wheel;
	}
}